srcFiles = dir('E:\10\Pictures\Man\*.jpg');
for i = 1 : length(srcFiles)
    filename = strcat('E:\10\Pictures\Man\',srcFiles(i).name);
    I = imread(filename);
    J = rgb2gray(I);
    BW = im2bw(I);
    barea = bwarea(BW);
    eu = bweuler(BW);
    CC = bwconncomp(BW);
    L = bwlabel(BW, 8);
    [L, num] = bwlabel(BW, 8);
    points = detectSURFFeatures(J);
    regions = detectMSERFeatures(J);
    hcornerdet = vision.CornerDetector;
    points = step(hcornerdet, I);
    [features, valid_points] = extractFeatures(I, points);
    
    

end
